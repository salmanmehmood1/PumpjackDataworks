// Fourier Series
const n = 5;
const x = 4
var i = 1;
while(i<=n){
    const a  = math.sin(n*x);
    const number = 1/n*a;
    console.log(number);
}